Reparar grub es una herramienta orientada a sistemas Ubuntu o debian el cual funciona en el 90% de distribuciones basadas en debian puede haber excepciones en el raro caso en el que la distribución cambie el nombre de los directorios simplemente ejecuta reparar-grub.sh con permisos de chroot desde un entorno live en la maquina que desea reparar y sigue los pasos que te de el programa 

## Licencia

Este proyecto está bajo la Licencia Pública General GNU (GNU GPL). 
Consulta el archivo [LICENSE] para obtener más detalles.

Copyright (C) 2025 [David Garcia Moga]

Este programa es software libre: puedes redistribuirlo y/o modificarlo bajo los términos de la Licencia Pública General de GNU según es publicada por la Free Software Foundation, bien de la versión 3 de dicha Licencia o (a tu elección) de cualquier versión posterior.

Este programa se distribuye con la esperanza de que sea útil, pero SIN NINGUNA GARANTÍA; ni siquiera la garantía implícita de COMERCIALIZACIÓN o ADECUACIÓN PARA UN PROPÓSITO PARTICULAR. Para más detalles, consulta la Licencia Pública General de GNU.